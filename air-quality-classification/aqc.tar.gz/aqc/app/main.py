from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import pickle
import pandas as pd

app = FastAPI()
# Mount the static directory for CSS, JS, images, etc.
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")

with open("app/model.pkl", "rb") as f:
    model, label_encoder = pickle.load(f)

@app.get("/aqc", response_class=HTMLResponse)
def form_get(request: Request):
    # Empty dict so defaults are used in template
    return templates.TemplateResponse("form.html", {"request": request, "request_form": {}})

@app.post("/aqc", response_class=HTMLResponse)
def form_post(request: Request,
              Temperature: float = Form(None),
              Humidity: float = Form(None),
              PM25: float = Form(None),
              PM10: float = Form(None),
              NO2: float = Form(None),
              SO2: float = Form(None),
              CO: float = Form(None),
              Proximity_to_Industrial_Areas: float = Form(None),
              Population_Density: float = Form(None)):

    input_values = [Temperature, Humidity, PM25, PM10, NO2, SO2, CO, Proximity_to_Industrial_Areas, Population_Density]
    input_array = [v if v is not None else -1 for v in input_values]
    input_df = pd.DataFrame([input_array], columns=[
        "Temperature", "Humidity", "PM2.5", "PM10", "NO2", "SO2", "CO", "Proximity_to_Industrial_Areas", "Population_Density"
    ])
    pred = model.predict(input_df)[0]
    label = label_encoder.inverse_transform([pred])[0] # Takes the numeric class (e.g., 2) and maps it back to its original string label "High"

    # Pass back the submitted form values to keep inputs populated after submit
    request_form = {
        'Temperature': Temperature,
        'Humidity': Humidity,
        'PM25': PM25,
        'PM10': PM10,
        'NO2': NO2,
        'SO2': SO2,
        'CO': CO,
        'Proximity_to_Industrial_Areas': Proximity_to_Industrial_Areas,
        'Population_Density': Population_Density
    }

    return templates.TemplateResponse("form.html", {
        "request": request,
        "result": label,
        "request_form": request_form
    })
