import pandas as pd
import sys
import pickle
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import f1_score, classification_report

def preprocess(df):
    df.fillna(-1, inplace=True)
    features = df.drop(columns=['Air Quality'])
    labels = df['Air Quality']
    le = LabelEncoder()
    y = le.fit_transform(labels)
    return features, y, le

def main():
    dataset_path = sys.argv[1]
    df = pd.read_csv(dataset_path)
    X, y, label_encoder = preprocess(df)

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    model = RandomForestClassifier()
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    print("F1 Score:", f1_score(y_test, y_pred, average='macro'))
    print("\nClassification Report:\n", classification_report(y_test, y_pred))

    with open("model.pkl", "wb") as f:
        pickle.dump((model, label_encoder), f)

if __name__ == "__main__":
    main()
